### Describe the Issue

### Steps to Reproduce

### Hardware/Software Info

Please provide the following information about your Raspberry Pi setup:

* Raspberry Pi model: 
* Operating System used: 
* Version of Python used: 
* SD card memory size: 
* Size of USB/other device used as swap (if building from source): 
* TensorFlow git commit hash (if building from source): 

### Relevant Console Output/Logs